<?php
/**
 * Plugin Name:       Chatbot Dirmik Unpad
 * Plugin URI:        https://pipp.unpad.ac.id
 * Description:       Chatbot AI Akademik untuk Direktorat Pendidikan Universitas Padjadjaran. Gunakan shortcode [dirmik_chatbot] atau [dirmik_chatbot mode="floating"].
 * Version:           1.3.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Pusat Inovasi Pengajaran dan Pembelajaran (PIPP) Universitas Padjadjaran
 * Author URI:        https://pipp.unpad.ac.id
 * License:           MIT
 * Text Domain:       chatbot-dirmik-unpad
 */

defined( 'ABSPATH' ) || exit;

define( 'DIRMIK_CHATBOT_VERSION',     '1.3.0' );
define( 'DIRMIK_CHATBOT_PLUGIN_FILE', __FILE__ );
define( 'DIRMIK_CHATBOT_DIR',         plugin_dir_path( __FILE__ ) );
define( 'DIRMIK_CHATBOT_URL',         plugin_dir_url( __FILE__ ) );
define( 'DIRMIK_CHATBOT_ASSETS_URL',  DIRMIK_CHATBOT_URL . 'assets/' );

require_once DIRMIK_CHATBOT_DIR . 'includes/class-chatbot-admin.php';
require_once DIRMIK_CHATBOT_DIR . 'includes/class-chatbot-widget.php';

add_action( 'plugins_loaded', function () {
    new DIRMIK_Chatbot_Admin();
    new DIRMIK_Chatbot_Widget();
} );

register_activation_hook( __FILE__, function () {
    $defaults = [
        'dirmik_chatbot_enabled'       => '1',
        'dirmik_chatbot_api_url'       => 'http://localhost:3000',
        'dirmik_chatbot_ws_url'        => 'ws://localhost:8080/ws',
        'dirmik_chatbot_bot_name'      => 'Asisten Direktorat Akademik Unpad',
        'dirmik_chatbot_bot_subtitle'  => 'Universitas Padjadjaran',
        'dirmik_chatbot_logo_url'      => '',
        'dirmik_chatbot_default_lang'  => 'id',
        'dirmik_chatbot_default_mode'  => 'embedded',
        'dirmik_chatbot_chat_height'   => '650px',
    ];
    foreach ( $defaults as $k => $v ) add_option( $k, $v );
} );

register_deactivation_hook( __FILE__, function () {
    // Cleanup transients on deactivation
    delete_transient( 'dirmik_chatbot_health_api' );
    delete_transient( 'dirmik_chatbot_health_ws' );
} );
