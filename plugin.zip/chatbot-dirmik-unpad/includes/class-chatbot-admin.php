<?php
/**
 * DIRMIK_Chatbot_Admin – Admin area handler v1.3.0
 * Provides: top-level menu, dashboard, settings, AJAX health-check.
 *
 * @package  ChatbotDirmikUnpad
 * @author   PIPP Universitas Padjadjaran
 * @version  1.3.0
 */
defined( 'ABSPATH' ) || exit;

class DIRMIK_Chatbot_Admin {

    private $slug        = 'dirmik-chatbot';
    private $opt_group   = 'dirmik_chatbot_options';
    private $plugin_name = 'Chatbot Direktorat Akademik Unpad';
    private $author      = 'Pusat Inovasi Pengajaran dan Pembelajaran (PIPP) Universitas Padjadjaran';

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        add_action( 'wp_ajax_dirmik_chatbot_test_connection', [ $this, 'ajax_test_connection' ] );
        add_action( 'wp_ajax_dirmik_chatbot_toggle_enabled',  [ $this, 'ajax_toggle_enabled' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Menu
    // ─────────────────────────────────────────────────────────────────────────
    public function add_menu() {
        $icon = 'data:image/svg+xml;base64,' . base64_encode(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#a7aaad" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
            . '<path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z"/>'
            . '<path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1"/>'
            . '</svg>'
        );

        add_menu_page(
            $this->plugin_name,
            'Chatbot',
            'manage_options',
            $this->slug,
            [ $this, 'render_dashboard_page' ],
            $icon,
            82
        );

        add_submenu_page(
            $this->slug,
            'Dashboard – ' . $this->plugin_name,
            'Dashboard',
            'manage_options',
            $this->slug,
            [ $this, 'render_dashboard_page' ]
        );

        add_submenu_page(
            $this->slug,
            'Pengaturan – ' . $this->plugin_name,
            'Pengaturan',
            'manage_options',
            $this->slug . '-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Admin Assets
    // ─────────────────────────────────────────────────────────────────────────
    public function enqueue_admin_assets( $hook ) {
        $allowed = [
            'toplevel_page_' . $this->slug,
            'chatbot_page_' . $this->slug . '-settings',
        ];
        if ( ! in_array( $hook, $allowed, true ) ) return;

        wp_enqueue_style(
            'dirmik-chatbot-admin',
            DIRMIK_CHATBOT_ASSETS_URL . 'css/chatbot-admin.css',
            [],
            DIRMIK_CHATBOT_VERSION
        );

        wp_enqueue_media();
        wp_enqueue_script( 'jquery' );
        wp_add_inline_script( 'jquery', $this->get_admin_js() );
    }

    private function get_admin_js() {
        $ajax_url = esc_url( admin_url( 'admin-ajax.php' ) );
        $nonce    = wp_create_nonce( 'dirmik_chatbot_admin' );
        return <<<JS
jQuery(function($){

    /* ── Media uploader ──────────────────────────────────────── */
    $(document).on('click', '.prodi-media-upload-btn', function(e) {
        e.preventDefault();
        var target = $(this).data('target');
        var frame  = wp.media({ title: 'Pilih Logo', multiple: false });
        frame.on('select', function() {
            var att = frame.state().get('selection').first().toJSON();
            $('#' + target).val(att.url);
            $('#' + target + '-preview').attr('src', att.url).show();
        });
        frame.open();
    });

    /* ── Health check ────────────────────────────────────────── */
    $(document).on('click', '#prodi-test-connection', function() {
        var btn = $(this);
        btn.prop('disabled', true).html('⏳ Memeriksa…');
        $('#prodi-health-results').html('<div class="prodi-admin-badge prodi-badge-checking">⏳ Menghubungkan ke backend…</div>');

        $.post('{$ajax_url}', {
            action  : 'dirmik_chatbot_test_connection',
            _wpnonce: '{$nonce}'
        }, function(res) {
            btn.prop('disabled', false).html('🔍 Tes Koneksi');
            if (res.success) {
                $('#prodi-health-results').html(res.data.html);
            } else {
                $('#prodi-health-results').html('<div class="prodi-admin-badge prodi-badge-error">❌ Gagal memeriksa koneksi.</div>');
            }
        }).fail(function() {
            btn.prop('disabled', false).html('🔍 Tes Koneksi');
            $('#prodi-health-results').html('<div class="prodi-admin-badge prodi-badge-error">❌ Request gagal. Periksa koneksi Anda.</div>');
        });
    });

    /* ── Enable / Disable toggle ─────────────────────────────── */
    $(document).on('change', '#prodi-enable-toggle', function() {
        var enabled = $(this).is(':checked') ? 1 : 0;
        var label   = $('#prodi-toggle-label');
        label.text('Menyimpan…');

        $.post('{$ajax_url}', {
            action  : 'dirmik_chatbot_toggle_enabled',
            enabled : enabled,
            _wpnonce: '{$nonce}'
        }, function(res) {
            if (res.success) {
                label.text(enabled ? 'Aktif' : 'Nonaktif');
                $('#prodi-status-pill')
                    .removeClass('prodi-pill-on prodi-pill-off')
                    .addClass(enabled ? 'prodi-pill-on' : 'prodi-pill-off')
                    .html(enabled ? '● Aktif' : '○ Nonaktif');
            } else {
                label.text('Gagal menyimpan');
            }
        });
    });

});
JS;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AJAX Handlers
    // ─────────────────────────────────────────────────────────────────────────
    public function ajax_test_connection() {
        check_ajax_referer( 'dirmik_chatbot_admin' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $api_url = esc_url_raw( get_option( 'dirmik_chatbot_api_url', '' ) );
        $ws_url  = sanitize_text_field( get_option( 'dirmik_chatbot_ws_url', '' ) );
        $html    = '';

        // Test API
        if ( $api_url ) {
            $ping_url = rtrim( $api_url, '/' ) . '/health';
            $response = wp_remote_get( $ping_url, [ 'timeout' => 6, 'sslverify' => false ] );
            if ( is_wp_error( $response ) ) {
                $html .= $this->health_badge( 'Backend API', false, $response->get_error_message() );
            } else {
                $code   = wp_remote_retrieve_response_code( $response );
                $ok     = ( $code >= 200 && $code < 300 );
                $body   = wp_remote_retrieve_body( $response );
                $data   = json_decode( $body, true );
                $detail = 'HTTP ' . $code;
                if ( $ok && ! empty( $data['prodi'] ) ) {
                    $detail .= ' · Prodi: ' . esc_html( $data['prodi'] );
                }
                $html .= $this->health_badge( 'Backend API', $ok, $detail );
            }
        } else {
            $html .= $this->health_badge( 'Backend API', false, 'URL belum dikonfigurasi' );
        }

        // Test WebSocket (via HTTP)
        if ( $ws_url ) {
            $http_url = preg_replace( '/^ws(s?):\/\//', 'http$1://', $ws_url );
            $http_url = preg_replace( '/\/ws$/', '/health', $http_url );
            $response = wp_remote_get( $http_url, [ 'timeout' => 5, 'sslverify' => false ] );
            if ( is_wp_error( $response ) ) {
                $html .= $this->health_badge( 'WebSocket Server', false, 'Tidak terjangkau' );
            } else {
                $code = wp_remote_retrieve_response_code( $response );
                $html .= $this->health_badge( 'WebSocket Server', ( $code >= 200 && $code < 500 ), 'HTTP ' . $code );
            }
        } else {
            $html .= $this->health_badge( 'WebSocket Server', false, 'URL belum dikonfigurasi' );
        }

        wp_send_json_success( [ 'html' => $html ] );
    }

    public function ajax_toggle_enabled() {
        check_ajax_referer( 'dirmik_chatbot_admin' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        $enabled = isset( $_POST['enabled'] ) ? (int) $_POST['enabled'] : 0;
        update_option( 'dirmik_chatbot_enabled', $enabled ? '1' : '0' );
        wp_send_json_success();
    }

    private function health_badge( $label, $ok, $detail = '' ) {
        $class = $ok ? 'prodi-badge-ok' : 'prodi-badge-error';
        $icon  = $ok ? '✅' : '❌';
        $det   = $detail ? ' <small style="opacity:.75">(' . esc_html( $detail ) . ')</small>' : '';
        return "<div class=\"prodi-admin-badge {$class}\">{$icon} {$label}{$det}</div>";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Register Settings
    // ─────────────────────────────────────────────────────────────────────────
    public function register_settings() {
        $fields = [
            'dirmik_chatbot_enabled'      => 'sanitize_text_field',
            'dirmik_chatbot_api_url'      => 'esc_url_raw',
            'dirmik_chatbot_ws_url'       => 'sanitize_text_field',
            'dirmik_chatbot_bot_name'     => 'sanitize_text_field',
            'dirmik_chatbot_bot_subtitle' => 'sanitize_text_field',
            'dirmik_chatbot_logo_url'     => 'esc_url_raw',
            'dirmik_chatbot_default_lang' => 'sanitize_text_field',
            'dirmik_chatbot_default_mode' => 'sanitize_text_field',
            'dirmik_chatbot_chat_height'  => 'sanitize_text_field',
        ];
        foreach ( $fields as $key => $sanitize ) {
            register_setting( $this->opt_group, $key, [ 'sanitize_callback' => $sanitize ] );
        }

        $page = $this->slug . '-settings';

        add_settings_section( 'dirmik_general',    'Umum',                  '__return_empty_string', $page );
        add_settings_field( 'dirmik_chatbot_enabled', 'Status Chatbot',     [ $this, 'field_enabled'  ], $page, 'dirmik_general' );

        add_settings_section( 'dirmik_connection', 'Koneksi Backend',        '__return_empty_string', $page );
        add_settings_field( 'dirmik_chatbot_api_url', 'Backend API URL',    [ $this, 'field_api_url' ], $page, 'dirmik_connection' );
        add_settings_field( 'dirmik_chatbot_ws_url',  'WebSocket URL',      [ $this, 'field_ws_url'  ], $page, 'dirmik_connection' );

        add_settings_section( 'dirmik_branding',   'Identitas & Tampilan',   '__return_empty_string', $page );
        add_settings_field( 'dirmik_chatbot_bot_name',     'Nama Bot',       [ $this, 'field_bot_name'     ], $page, 'dirmik_branding' );
        add_settings_field( 'dirmik_chatbot_bot_subtitle', 'Subjudul Bot',   [ $this, 'field_bot_subtitle' ], $page, 'dirmik_branding' );
        add_settings_field( 'dirmik_chatbot_logo_url',     'Logo Chatbot',   [ $this, 'field_logo_url'     ], $page, 'dirmik_branding' );

        add_settings_section( 'dirmik_display',    'Tampilan Widget',        '__return_empty_string', $page );
        add_settings_field( 'dirmik_chatbot_default_lang', 'Bahasa Default',          [ $this, 'field_default_lang' ], $page, 'dirmik_display' );
        add_settings_field( 'dirmik_chatbot_default_mode', 'Mode Tampilan',           [ $this, 'field_default_mode' ], $page, 'dirmik_display' );
        add_settings_field( 'dirmik_chatbot_chat_height',  'Tinggi Chat (embedded)',  [ $this, 'field_chat_height'  ], $page, 'dirmik_display' );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Field Renderers
    // ─────────────────────────────────────────────────────────────────────────
    public function field_enabled() {
        $v      = get_option( 'dirmik_chatbot_enabled', '1' );
        $label  = $v === '1' ? 'Aktif' : 'Nonaktif';
        echo '<label class="prodi-toggle-wrap">';
        echo '<input type="hidden" name="dirmik_chatbot_enabled" value="0">';
        echo '<input type="checkbox" name="dirmik_chatbot_enabled" value="1" ' . checked( $v, '1', false ) . '>';
        echo '<span class="prodi-toggle-slider"></span>';
        echo '</label>';
        echo '<span class="prodi-toggle-label">' . esc_html( $label ) . '</span>';
        echo '<p class="description" style="margin-top:6px;">Nonaktifkan untuk menonaktifkan semua widget chatbot tanpa harus melepas plugin.</p>';
    }

    public function field_api_url() {
        $v = get_option( 'dirmik_chatbot_api_url', 'http://localhost:5000' );
        echo '<input type="url" name="dirmik_chatbot_api_url" value="' . esc_attr( $v ) . '" class="regular-text" placeholder="http://localhost:5000">';
        echo '<p class="description">URL REST API backend Node.js. Contoh: <code>https://api.prodi-anda.unpad.ac.id</code></p>';
    }

    public function field_ws_url() {
        $v = get_option( 'dirmik_chatbot_ws_url', 'ws://localhost:8080/ws' );
        echo '<input type="text" name="dirmik_chatbot_ws_url" value="' . esc_attr( $v ) . '" class="regular-text" placeholder="ws://localhost:8080/ws">';
        echo '<p class="description">URL WebSocket untuk streaming respons AI. Gunakan <code>wss://</code> pada HTTPS.</p>';
    }

    public function field_bot_name() {
        $v = get_option( 'dirmik_chatbot_bot_name', 'Asisten Direktorat Akademik Unpad' );
        echo '<input type="text" name="dirmik_chatbot_bot_name" value="' . esc_attr( $v ) . '" class="regular-text">';
        echo '<p class="description">Nama yang ditampilkan di header widget chatbot.</p>';
    }

    public function field_bot_subtitle() {
        $v = get_option( 'dirmik_chatbot_bot_subtitle', 'Universitas Padjadjaran' );
        echo '<input type="text" name="dirmik_chatbot_bot_subtitle" value="' . esc_attr( $v ) . '" class="regular-text">';
        echo '<p class="description">Subjudul / institusi yang ditampilkan di bawah nama bot.</p>';
    }

    public function field_logo_url() {
        $v   = get_option( 'dirmik_chatbot_logo_url', '' );
        $src = esc_attr( $v );
        $dsp = $src ? 'display:inline-block' : 'display:none';
        echo '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">';
        echo '<input type="text" id="dirmik_chatbot_logo_url" name="dirmik_chatbot_logo_url" value="' . $src . '" class="regular-text" placeholder="https://… atau kosongkan untuk logo default">';
        echo '<button type="button" class="button prodi-media-upload-btn" data-target="dirmik_chatbot_logo_url">📁 Pilih dari Media</button>';
        echo '</div>';
        echo '<img id="dirmik_chatbot_logo_url-preview" src="' . $src . '" style="margin-top:10px;max-height:64px;border-radius:8px;border:1px solid var(--dc-border);padding:4px;' . $dsp . '">';
        echo '<p class="description">Logo di header chatbot. Kosongkan untuk menggunakan logo default direktorat akademik.</p>';
    }

    public function field_default_lang() {
        $v = get_option( 'dirmik_chatbot_default_lang', 'id' );
        echo '<select name="dirmik_chatbot_default_lang">';
        echo '<option value="id"' . selected( $v, 'id', false ) . '>🇮🇩 Bahasa Indonesia</option>';
        echo '<option value="en"' . selected( $v, 'en', false ) . '>🇬🇧 English</option>';
        echo '</select>';
        echo '<p class="description">Dapat di-override per-shortcode: <code>[dirmik_chatbot lang="en"]</code></p>';
    }

    public function field_default_mode() {
        $v = get_option( 'dirmik_chatbot_default_mode', 'embedded' );
        echo '<select name="dirmik_chatbot_default_mode">';
        echo '<option value="embedded"' . selected( $v, 'embedded', false ) . '>📄 Embedded — tampil di dalam halaman</option>';
        echo '<option value="floating"' . selected( $v, 'floating', false ) . '>💬 Floating — tombol mengambang di pojok</option>';
        echo '</select>';
        echo '<p class="description">Override per-shortcode: <code>[dirmik_chatbot mode="floating"]</code></p>';
    }

    public function field_chat_height() {
        $v = get_option( 'dirmik_chatbot_chat_height', '650px' );
        echo '<input type="text" name="dirmik_chatbot_chat_height" value="' . esc_attr( $v ) . '" class="small-text" placeholder="650px">';
        echo '<p class="description">Contoh: <code>650px</code> atau <code>80vh</code>. Hanya berlaku pada mode Embedded.</p>';
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Dashboard Page
    // ─────────────────────────────────────────────────────────────────────────
    public function render_dashboard_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $enabled      = get_option( 'dirmik_chatbot_enabled', '1' ) === '1';
        $api_url      = get_option( 'dirmik_chatbot_api_url', '' );
        $ws_url       = get_option( 'dirmik_chatbot_ws_url', '' );
        $bot_name     = get_option( 'dirmik_chatbot_bot_name', 'Asisten Direktorat Akademik Unpad' );
        $settings_url = admin_url( 'admin.php?page=' . $this->slug . '-settings' );

        $admin_dashboard_url = '';
        if ( $api_url ) {
            $parsed = parse_url( $api_url );
            $scheme = isset( $parsed['scheme'] ) ? $parsed['scheme'] : 'http';
            $host   = isset( $parsed['host'] )   ? $parsed['host']   : 'localhost';
            $admin_dashboard_url = $scheme . '://' . $host . ':3000/Admin';
        }
        ?>
        <div class="prodi-admin-wrap">
            <?php $this->render_page_header(
                'Dashboard',
                $this->plugin_name,
                'Pantau status dan konfigurasi chatbot Direktorat Akademik Anda'
            ); ?>

            <!-- Stat cards -->
            <div class="prodi-admin-grid-3">
                <div class="prodi-admin-card">
                    <div class="prodi-card-label">Status Chatbot</div>
                    <div id="prodi-status-pill" class="prodi-pill <?php echo $enabled ? 'prodi-pill-on' : 'prodi-pill-off'; ?>">
                        <?php echo $enabled ? '● Aktif' : '○ Nonaktif'; ?>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;margin-top:12px;">
                        <label class="prodi-toggle-wrap">
                            <input type="checkbox" id="prodi-enable-toggle" <?php checked( $enabled ); ?>>
                            <span class="prodi-toggle-slider"></span>
                        </label>
                        <span id="prodi-toggle-label" class="prodi-toggle-label">
                            <?php echo $enabled ? 'Aktif' : 'Nonaktif'; ?>
                        </span>
                    </div>
                </div>

                <div class="prodi-admin-card">
                    <div class="prodi-card-label">Versi Plugin</div>
                    <div class="prodi-card-value"><?php echo esc_html( DIRMIK_CHATBOT_VERSION ); ?></div>
                    <div class="prodi-card-sub">Nama Bot: <strong><?php echo esc_html( $bot_name ); ?></strong></div>
                </div>

                <div class="prodi-admin-card">
                    <div class="prodi-card-label">Pengaturan</div>
                    <a href="<?php echo esc_url( $settings_url ); ?>" class="prodi-btn prodi-btn-primary" style="margin-top:10px;">
                        ⚙️ Buka Pengaturan
                    </a>
                    <?php if ( $admin_dashboard_url ) : ?>
                        <a href="<?php echo esc_url( $admin_dashboard_url ); ?>" target="_blank" class="prodi-btn prodi-btn-outline" style="margin-top:8px;">
                            ↗ Admin Dashboard
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Connection & Shortcode info -->
            <div class="prodi-admin-grid-2" style="margin-top:20px;">
                <div class="prodi-admin-card-full">
                    <h3 class="prodi-section-title">🔌 Koneksi Backend</h3>
                    <div class="prodi-connection-info">
                        <div class="prodi-conn-row">
                            <span class="prodi-conn-label">API URL</span>
                            <code class="prodi-conn-val"><?php echo $api_url ? esc_html( $api_url ) : '<em>Belum dikonfigurasi</em>'; ?></code>
                        </div>
                        <div class="prodi-conn-row">
                            <span class="prodi-conn-label">WebSocket URL</span>
                            <code class="prodi-conn-val"><?php echo $ws_url ? esc_html( $ws_url ) : '<em>Belum dikonfigurasi</em>'; ?></code>
                        </div>
                        <?php if ( $admin_dashboard_url ) : ?>
                        <div class="prodi-conn-row">
                            <span class="prodi-conn-label">Admin Panel</span>
                            <code class="prodi-conn-val"><?php echo esc_html( $admin_dashboard_url ); ?></code>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div style="display:flex;align-items:center;gap:10px;margin-top:16px;flex-wrap:wrap;">
                        <button id="prodi-test-connection" class="prodi-btn prodi-btn-primary">
                            🔍 Tes Koneksi
                        </button>
                        <?php if ( $admin_dashboard_url ) : ?>
                            <a href="<?php echo esc_url( $admin_dashboard_url ); ?>" target="_blank" class="prodi-btn prodi-btn-outline">
                                ↗ Buka Admin Dashboard
                            </a>
                        <?php endif; ?>
                    </div>
                    <div id="prodi-health-results" style="margin-top:12px;"></div>
                </div>

                <div class="prodi-admin-card-full">
                    <h3 class="prodi-section-title">📌 Cara Penggunaan Shortcode</h3>
                    <div class="prodi-shortcode-list">
                        <div class="prodi-shortcode-item">
                            <span class="prodi-shortcode-label">Embedded (default)</span>
                            <code>[dirmik_chatbot]</code>
                        </div>
                        <div class="prodi-shortcode-item">
                            <span class="prodi-shortcode-label">Floating (mengambang)</span>
                            <code>[dirmik_chatbot mode="floating"]</code>
                        </div>
                        <div class="prodi-shortcode-item">
                            <span class="prodi-shortcode-label">Override bahasa</span>
                            <code>[dirmik_chatbot lang="en"]</code>
                        </div>
                        <div class="prodi-shortcode-item">
                            <span class="prodi-shortcode-label">Override tinggi</span>
                            <code>[dirmik_chatbot height="500px"]</code>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Requirements -->
            <div class="prodi-admin-card-full prodi-card-warning" style="margin-top:20px;">
                <h3 class="prodi-section-title" style="border-color:#fde68a;">⚠️ Prasyarat Backend</h3>
                <ul class="prodi-req-list">
                    <li>✅ Node.js backend berjalan pada port yang dikonfigurasi di atas</li>
                    <li>✅ WebSocket AI server aktif dan dapat dijangkau</li>
                    <li>✅ Python FastAPI / RAG server berjalan</li>
                    <li>✅ MongoDB Atlas terhubung</li>
                    <li>✅ CORS dikonfigurasi untuk domain WordPress ini</li>
                </ul>
            </div>

            <?php $this->render_footer(); ?>
        </div>
        <?php
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Settings Page
    // ─────────────────────────────────────────────────────────────────────────
    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $dashboard_url = admin_url( 'admin.php?page=' . $this->slug );
        $api_url       = get_option( 'dirmik_chatbot_api_url', '' );

        $admin_dashboard_url = '';
        if ( $api_url ) {
            $parsed = parse_url( $api_url );
            $scheme = isset( $parsed['scheme'] ) ? $parsed['scheme'] : 'http';
            $host   = isset( $parsed['host'] )   ? $parsed['host']   : 'localhost';
            $admin_dashboard_url = $scheme . '://' . $host . ':3000/Admin';
        }
        ?>
        <div class="prodi-admin-wrap">
            <?php $this->render_page_header(
                'Pengaturan',
                $this->plugin_name,
                'Konfigurasi chatbot AI untuk Direktorat Akademik Anda'
            ); ?>

            <p style="margin-bottom:20px;">
                <a href="<?php echo esc_url( $dashboard_url ); ?>" class="prodi-btn prodi-btn-outline">
                    ← Kembali ke Dashboard
                </a>
            </p>

            <?php settings_errors( $this->opt_group ); ?>

            <div class="prodi-settings-layout">
                <!-- Main form -->
                <div class="prodi-settings-main">
                    <form method="post" action="options.php" class="prodi-admin-card-full">
                        <?php
                        settings_fields( $this->opt_group );
                        do_settings_sections( $this->slug . '-settings' );
                        submit_button( '💾 Simpan Pengaturan', 'primary large' );
                        ?>
                    </form>
                </div>

                <!-- Sidebar -->
                <div class="prodi-settings-sidebar">

                    <!-- Shortcodes -->
                    <div class="prodi-admin-card-full">
                        <h3 class="prodi-section-title">📌 Shortcode</h3>
                        <div class="prodi-shortcode-list">
                            <div class="prodi-shortcode-item">
                                <span class="prodi-shortcode-label">Embedded</span>
                                <code>[dirmik_chatbot]</code>
                            </div>
                            <div class="prodi-shortcode-item">
                                <span class="prodi-shortcode-label">Floating</span>
                                <code>[dirmik_chatbot mode="floating"]</code>
                            </div>
                            <div class="prodi-shortcode-item">
                                <span class="prodi-shortcode-label">Override Bahasa</span>
                                <code>[dirmik_chatbot lang="en"]</code>
                            </div>
                        </div>
                    </div>

                    <!-- Admin Backend -->
                    <div class="prodi-admin-card-full">
                        <h3 class="prodi-section-title">🔧 Admin Backend</h3>
                        <?php if ( $admin_dashboard_url ) : ?>
                            <p style="font-size:12px;color:var(--dc-text-muted);margin-bottom:10px;">
                                Akses dashboard terpisah untuk mengelola Knowledge Base, riwayat chat, dan pengguna.
                            </p>
                            <a href="<?php echo esc_url( $admin_dashboard_url ); ?>" target="_blank" class="prodi-admin-link-box">
                                <div class="prodi-admin-link-box-icon">↗</div>
                                <div class="prodi-admin-link-box-text">
                                    <strong>Buka Admin Dashboard</strong>
                                    <span><?php echo esc_html( $admin_dashboard_url ); ?></span>
                                </div>
                            </a>
                        <?php else : ?>
                            <p style="font-size:12px;color:var(--dc-gold);">
                                ⚠️ Isi <strong>Backend API URL</strong> terlebih dahulu untuk mengaktifkan tautan ini.
                            </p>
                        <?php endif; ?>
                    </div>

                    <!-- Environment note -->
                    <div class="prodi-admin-card-full prodi-card-info">
                        <h3 class="prodi-section-title" style="border-color:var(--dc-info-border);">ℹ️ Konfigurasi .env</h3>
                        <p style="font-size:12px;color:var(--dc-text-muted);line-height:1.65;margin:0;">
                            Variabel seperti <code>MONGO_URI</code>, <code>GROQ_API_KEY</code>, dan <code>LLM_PROVIDER</code>
                            harus dikonfigurasi langsung di file <strong>.env</strong> pada server backend
                            demi keamanan kredensial.
                        </p>
                    </div>

                    <!-- Plugin info -->
                    <div class="prodi-admin-card-full">
                        <h3 class="prodi-section-title">ℹ️ Info Plugin</h3>
                        <table class="prodi-info-table">
                            <tr><td>Versi</td><td><strong><?php echo esc_html( DIRMIK_CHATBOT_VERSION ); ?></strong></td></tr>
                            <tr><td>Shortcode</td><td><code>[dirmik_chatbot]</code></td></tr>
                            <tr><td>PHP Min.</td><td>7.4+</td></tr>
                            <tr><td>WP Min.</td><td>5.6+</td></tr>
                            <tr><td>Pengembang</td><td style="font-size:11px;line-height:1.5;"><?php echo esc_html( $this->author ); ?></td></tr>
                        </table>
                    </div>

                </div>
            </div>

            <?php $this->render_footer(); ?>
        </div>
        <?php
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Shared helpers
    // ─────────────────────────────────────────────────────────────────────────
    private function render_page_header( $page, $title, $subtitle ) {
        ?>
        <div class="prodi-admin-header">
            <div class="prodi-admin-header-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z"/>
                    <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1"/>
                </svg>
            </div>
            <div class="prodi-admin-header-content">
                <div class="prodi-admin-header-page"><?php echo esc_html( $page ); ?></div>
                <h1 class="prodi-admin-header-title"><?php echo esc_html( $title ); ?></h1>
                <p class="prodi-admin-header-sub"><?php echo esc_html( $subtitle ); ?></p>
            </div>
        </div>
        <?php
    }

    private function render_footer() {
        ?>
        <div class="prodi-admin-footer">
            <div class="prodi-admin-footer-text">
                Dikembangkan oleh <strong><?php echo esc_html( $this->author ); ?></strong>
            </div>
            <span class="prodi-admin-footer-version">v<?php echo esc_html( DIRMIK_CHATBOT_VERSION ); ?></span>
        </div>
        <?php
    }
}
