<?php
/**
 * Plugin Name:       Chatbot Direktorat Akademik Unpad
 * Plugin URI:        https://dirmik.unpad.ac.id
 * Description:       Chatbot AI Akademik Direktorat Akademik Universitas Padjadjaran. Pasang dengan shortcode [dirmik_chatbot] atau [dirmik_chatbot mode="floating"].
 * Version:           1.1.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Direktorat Akademik Unpad Dev Team
 * License:           MIT
 * Text Domain:       chatbot-dirmik-unpad
 */

defined( 'ABSPATH' ) || exit;

define( 'DIRMIK_CHATBOT_VERSION',    '1.1.0' );
define( 'DIRMIK_CHATBOT_DIR',        plugin_dir_path( __FILE__ ) );
define( 'DIRMIK_CHATBOT_URL',        plugin_dir_url( __FILE__ ) );
define( 'DIRMIK_CHATBOT_ASSETS_URL', DIRMIK_CHATBOT_URL . 'assets/' );

require_once DIRMIK_CHATBOT_DIR . 'includes/class-chatbot-admin.php';
require_once DIRMIK_CHATBOT_DIR . 'includes/class-chatbot-widget.php';

add_action( 'plugins_loaded', function () {
    new DIRMIK_Chatbot_Admin();
    new DIRMIK_Chatbot_Widget();
} );

register_activation_hook( __FILE__, function () {
    $defaults = [
        'dirmik_chatbot_api_url'       => 'http://localhost:3000',
        'dirmik_chatbot_ws_url'        => 'ws://localhost:8080/ws',
        'dirmik_chatbot_bot_name'      => 'Asisten Direktorat Akademik Unpad',
        'dirmik_chatbot_bot_subtitle'  => 'Universitas Padjadjaran',
        'dirmik_chatbot_logo_url'      => '',
        'dirmik_chatbot_default_lang'  => 'id',
        'dirmik_chatbot_default_mode'  => 'embedded',
        'dirmik_chatbot_chat_height'   => '650px',
    ];
    foreach ( $defaults as $k => $v ) add_option( $k, $v );
} );
