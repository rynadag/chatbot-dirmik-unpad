<?php
defined( 'ABSPATH' ) || exit;

class DIRMIK_Chatbot_Widget {

    public function __construct() {
        add_shortcode( 'dirmik_chatbot', [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );
    }

    public function register_assets() {
        wp_register_style(
            'dirmik-chatbot-frontend',
            DIRMIK_CHATBOT_ASSETS_URL . 'css/chatbot-frontend.css',
            [],
            DIRMIK_CHATBOT_VERSION
        );
        wp_register_script(
            'dirmik-chatbot-frontend',
            DIRMIK_CHATBOT_ASSETS_URL . 'js/chatbot-frontend.js',
            [],
            DIRMIK_CHATBOT_VERSION,
            true
        );

        $logo = get_option( 'dirmik_chatbot_logo_url', '' );
        if ( empty( $logo ) ) {
            $logo = DIRMIK_CHATBOT_ASSETS_URL . 'images/dirmik-logo-default.svg';
        }

        wp_localize_script( 'dirmik-chatbot-frontend', 'dirmikChatbotConfig', [
            'apiUrl'      => esc_url_raw( get_option( 'dirmik_chatbot_api_url',      'http://localhost:3000' ) ),
            'wsUrl'       => sanitize_text_field( get_option( 'dirmik_chatbot_ws_url', 'ws://localhost:8080/ws' ) ),
            'botName'     => sanitize_text_field( get_option( 'dirmik_chatbot_bot_name',     'Asisten Direktorat Akademik Unpad' ) ),
            'botSubtitle' => sanitize_text_field( get_option( 'dirmik_chatbot_bot_subtitle', 'Universitas Padjadjaran' ) ),
            'logoUrl'     => esc_url( $logo ),
            'defaultLang' => sanitize_text_field( get_option( 'dirmik_chatbot_default_lang', 'id' ) ),
            'chatHeight'  => sanitize_text_field( get_option( 'dirmik_chatbot_chat_height',  '650px' ) ),
        ] );
    }

    public function render_shortcode( $atts ) {
        // Respect the enabled toggle
        if ( get_option( 'dirmik_chatbot_enabled', '1' ) !== '1' ) {
            return '';
        }

        $atts = shortcode_atts( [
            'mode'   => get_option( 'dirmik_chatbot_default_mode', 'embedded' ),
            'lang'   => '',
            'height' => '',
        ], $atts, 'dirmik_chatbot' );

        $mode   = in_array( $atts['mode'], [ 'embedded', 'floating' ], true ) ? $atts['mode'] : 'embedded';
        $lang   = in_array( $atts['lang'], [ 'id', 'en' ], true ) ? $atts['lang'] : '';
        $height = ! empty( $atts['height'] ) ? sanitize_text_field( $atts['height'] ) : '';

        wp_enqueue_style( 'dirmik-chatbot-frontend' );
        wp_enqueue_script( 'dirmik-chatbot-frontend' );

        static $n = 0; $n++;
        $uid = 'dirmik-chatbot-' . $n . '-' . substr( md5( uniqid() ), 0, 6 );

        $data  = 'data-mode="' . esc_attr( $mode ) . '"';
        if ( $lang )   $data .= ' data-lang="'   . esc_attr( $lang )   . '"';
        if ( $height ) $data .= ' data-height="' . esc_attr( $height ) . '"';

        return '<div id="' . esc_attr( $uid ) . '" class="dirmik-chatbot-root" ' . $data . '></div>';
    }
}
